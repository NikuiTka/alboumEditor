/* cover-engine.js - Logic for Rendering & Cropping V78 */

const CONFIG = {
    dpi: 300, 
    cmToInch: 2.54, 
    spineWidthCm: 1.5, 
    renderScale: 3.0,
    globalOpacity: 1.0, 
    typo: { baseTitle: 1.2, baseDetails: 0.5, baseCopy: 0.35 },
    scales: [0.5, 0.75, 1.0, 1.25, 1.5]
};

const CoverEngine = {
    canvas: null,
    
    init: function(canvasId) {
        this.canvas = new fabric.Canvas(canvasId, { backgroundColor: '#fff', selection: false, enableRetinaScaling: false });
        
        this.canvas.on('mouse:down', (e) => {
            if(e.target) {
                if(e.target.isMain || e.target.isPlaceholder) {
                    if(window.handleCanvasClick) window.handleCanvasClick(e.target.isMain ? 'mainImage' : 'placeholder');
                }
                else if (e.target.isIcon) {
                    if(window.openGallery) window.openGallery('symbols', 'global');
                }
            }
        });

        this.canvas.on('mouse:up', (e) => {
            const isMobile = window.innerWidth <= 900;
            const hitInteractive = e.target && (e.target.isMain || e.target.isPlaceholder || e.target.isIcon);
            
            if (isMobile && e.isClick && !hitInteractive) {
                setTimeout(() => {
                    if(window.openMobilePreview) window.openMobilePreview();
                }, 100);
            }
        });
    },

    loadSimpleImage: function(path, callback) {
        const img = new Image();
        img.onload = () => callback(path);
        img.onerror = () => { callback(null); };
        img.src = path;
    },

    updateDimensions: function(container, state) {
        if(!container || container.clientWidth === 0) return;
        const isMobile = window.innerWidth < 900;
        const margin = isMobile ? 10 : 20; 
        
        const curBookSize = parseFloat(state.bookSize);
        const curW = curBookSize * 2 + CONFIG.spineWidthCm; 
        const curH = curBookSize;

        let basePPI;
        if (isMobile) {
            const safeW = container.clientWidth - (margin * 2);
            const safeH = container.clientHeight - (margin * 2);
            basePPI = Math.min(safeW / curW, safeH / curH);
        } else {
            const MAX_REF_SIZE = 30; 
            const maxRefW = MAX_REF_SIZE * 2 + CONFIG.spineWidthCm; 
            const maxRefH = MAX_REF_SIZE;
            basePPI = Math.max(5, Math.min(
                (container.clientWidth - margin*2) / maxRefW, 
                (container.clientHeight - margin*2) / maxRefH
            ));
        }

        state.ppi = basePPI * CONFIG.renderScale;
        this.canvas.setWidth(curW * state.ppi); 
        this.canvas.setHeight(curH * state.ppi);
        this.canvas.wrapperEl.style.width = `${curW * basePPI}px`; 
        this.canvas.wrapperEl.style.height = `${curH * basePPI}px`;
        this.canvas.lowerCanvasEl.style.width = '100%'; this.canvas.upperCanvasEl.style.width = '100%';
        this.canvas.lowerCanvasEl.style.height = '100%'; this.canvas.upperCanvasEl.style.height = '100%';
        
        this.render(state);
    },

    render: function(state) {
        if(!this.canvas) return;
        this.canvas.clear(); 
        this.canvas.setBackgroundColor(state.coverColor);
        
        const h = this.canvas.height;
        const bookSize = parseFloat(state.bookSize);
        const x1 = bookSize * state.ppi; 
        const x2 = (bookSize + 1.5) * state.ppi;
        
        const c = { 
            h: h, spineX: x1 + ((x2 - x1) / 2), 
            frontCenter: x2 + (bookSize * state.ppi / 2), 
            backCenter: (bookSize * state.ppi) / 2, 
            bottomBase: h - (1.5 * state.ppi), 
            centerY: h / 2, gap: 2.0 * state.ppi 
        };

        this._drawGuides(x1, x2, h, state);
        this._renderSpine(c, state);
        this._renderBackCover(c, state);
        this._renderFrontCover(c, state);
    },

    _drawGuides: function(x1, x2, h, state) {
        const opts = { stroke: state.text.color, strokeWidth: 2, strokeDashArray: [10,10], selectable: false, evented: false, opacity: 0.3 };
        this.canvas.add(new fabric.Line([x1, 0, x1, h], opts)); 
        this.canvas.add(new fabric.Line([x2, 0, x2, h], opts));
    },

    _renderSpine: function(c, state) {
        if(state.spine.symbol && state.images.icon) {
            this._placeImage(state.images.icon, c.spineX, c.bottomBase, 1.0 * state.ppi, { originY: 'bottom', color: state.text.color, isIcon: true, hoverCursor: 'pointer' });
        }
        let parts = [];
        const raw = state.text.lines.map(l => l.text);
        if(state.spine.title) {
            const processed = raw.map((txt, i) => state.text.lines[i].upper ? txt.toUpperCase() : txt).filter(Boolean);
            if(processed.length > 0) parts.push(processed.join(" "));
        }
        if(state.spine.date && state.text.date) parts.push(state.text.date);
        
        if(parts.length > 0) {
            const spineStr = parts.join("  •  ");
            let yPos = c.bottomBase; 
            if(state.spine.symbol && state.images.icon) yPos -= (1.8 * state.ppi);
            const fontSize = CONFIG.typo.baseDetails * state.ppi; 
            const textYPos = yPos - (0.5 * state.ppi); // Lift slightly
            
            this.canvas.add(new fabric.Text(spineStr, { 
                fontFamily: 'Tenor Sans', fontSize: fontSize, fill: state.text.color, opacity: CONFIG.globalOpacity, 
                originX: 'left', originY: 'center', left: c.spineX, top: textYPos, angle: -90, selectable: false, letterSpacing: 100 
            }));
        }
    },

    _renderBackCover: function(c, state) {
        if(state.text.copyright) {
            const fontSize = CONFIG.typo.baseCopy * state.ppi;
            this.canvas.add(new fabric.Text(state.text.copyright, { 
                left: c.backCenter, top: c.bottomBase, fontSize: fontSize, fontFamily: 'Tenor Sans', fill: state.text.color, 
                opacity: CONFIG.globalOpacity * 0.7, originX: 'center', originY: 'bottom', selectable: false, letterSpacing: 80 
            }));
        }
        if(state.qr.enabled && state.qr.url) {
            const qrObj = new QRious({ value: state.qr.url, size: 500, level: 'H', foreground: state.text.color, backgroundAlpha: 0 });
            this._placeImage(qrObj.toDataURL(), c.backCenter, c.bottomBase - (0.5 * state.ppi) - (0.35 * state.ppi) - (0.5*state.ppi), 1.2 * state.ppi, { originY: 'bottom' });
        }
    },

    _renderFrontCover: function(c, state) {
        const layout = state.layout; const x = c.frontCenter; const y = c.centerY; 
        if (layout === 'magazine') {
            const coverW = state.bookSize * state.ppi; const coverH = c.h; 
            if(state.images.main) this._placeClippedImage(state.images.main, x, y, coverW, coverH, 'rect', false, state);
            else this._renderImageSlot(x, y, state, { w: coverW, h: coverH });
            this._renderTextBlock(x, 2.0 * state.ppi, false, true, state);
        } 
        else if (layout === 'icon') { this._renderIcon(x, y, null, state); }
        else if (layout === 'text_icon') {
            const gap = c.gap; const dynGap = gap * state.text.scale; const tObj = this._createTextBlockObj(true, state);
            const iconSize = (2.0 / 1.6) * state.ppi * state.text.scale; const visualGap = dynGap * 1.5; 
            const totalH = tObj.height + visualGap + iconSize; const startY = y - (totalH / 2); 
            tObj.set({ left: x, top: startY + tObj.height/2 }); this.canvas.add(tObj);
            this._renderIcon(x, startY + tObj.height + visualGap + iconSize/2, iconSize, state);
        } 
        else if (layout === 'graphic' || layout === 'photo_text') {
            let imgY = c.centerY; 
            if(layout === 'graphic') {
                const style = getComputedStyle(document.documentElement);
                const offsetCm = parseFloat(style.getPropertyValue('--graphic-offset-y-cm')) || 2;
                imgY = c.centerY - (offsetCm * state.ppi);
                if(state.images.main) this._renderNaturalImage(x, imgY, state);
                else this._renderImageSlot(x, imgY, state);
            } else {
                const zoom = state.text.scale || 1.0;
                const w = state.slotSize.w * state.ppi * zoom; const h = state.slotSize.h * state.ppi * zoom;
                imgY = c.centerY - (2.0 * state.ppi); 
                if(state.images.main) this._placeClippedImage(state.images.main, x, imgY, w, h, state.maskType, false, state);
                else this._renderImageSlot(x, imgY, state, {w: w, h: h});
                const textY = imgY + (h / 2) + (1.5 * state.ppi);
                this._renderTextBlock(x, textY, true, false, state, 'top'); 
            }
        }
        else if (layout === 'text') { const tObj = this._createTextBlockObj(false, state); tObj.set({ left: x, top: c.centerY }); this.canvas.add(tObj); } 
    },

    _createTextBlockObj: function(compact, state) {
        const rawLines = state.text.lines.map(l => l.text); 
        const processedLines = rawLines.map((txt, i) => { return state.text.lines[i].upper ? txt.toUpperCase() : txt; });
        const hasText = rawLines.some(t => t.length > 0);
        let renderTxt = hasText ? processedLines.filter(Boolean).join("\n") : "THE VISUAL DIARY\n\n\n";
        let opacity = hasText ? CONFIG.globalOpacity : 0.3;
        const baseSize = compact ? 0.8 : CONFIG.typo.baseTitle; const finalSize = baseSize * state.ppi * state.text.scale;
        const tObj = new fabric.Text(renderTxt, { fontFamily: state.text.font, fontSize: finalSize, textAlign: 'center', lineHeight: 1.3, fill: state.text.color, opacity: opacity, selectable: false, originX: 'center', originY: 'center', hoverCursor: 'default' });
        const group = new fabric.Group([tObj], { originX: 'center', originY: 'center', hoverCursor: 'default' });
        if(state.text.date) { 
            const dateStr = state.text.date; const dateOp = CONFIG.globalOpacity; const dateSize = CONFIG.typo.baseDetails * state.ppi * state.text.scale;
            const gap = (compact ? 1.0 : 2.0) * state.ppi;
            const dObj = new fabric.Text(dateStr, { fontFamily: state.text.font, fontSize: dateSize, fill: state.text.color, opacity: dateOp, originX: 'center', originY: 'top', top: (tObj.height / 2) + gap, hoverCursor: 'default' });
            group.addWithUpdate(dObj);
        }
        return group;
    },

    _renderTextBlock: function(x, y, compact, isMag, state, verticalOrigin = 'center') {
        if(state.layout === 'graphic') return;
        if(isMag) {
            let l1 = String(state.text.lines[0].text || ""); let l2 = String(state.text.lines[1].text || ""); let l3 = String(state.text.lines[2].text || ""); 
            if(state.text.lines[0].upper) l1 = l1.toUpperCase(); if(state.text.lines[1].upper) l2 = l2.toUpperCase(); if(state.text.lines[2].upper) l3 = l3.toUpperCase();
            let txtParts = [l1, l2, l3].filter(t => t.length > 0); if (txtParts.length === 0) return;
            let txt = txtParts.join("\n");
            const shadow = new fabric.Shadow({ color: 'rgba(0,0,0,0.15)', blur: 4, offsetX: 0, offsetY: 0 });
            const mainTextObj = new fabric.Text(txt, { fontFamily: state.text.font, fontSize: 2.5 * state.ppi * state.text.scale, textAlign: 'center', lineHeight: 1.0, originX: 'center', originY: 'top', left: x, top: y, fill: state.text.color, selectable: false, evented: false, shadow: shadow, hoverCursor: 'default' });
            this.canvas.add(mainTextObj);
            if(state.text.date) {
                const dateObj = new fabric.Text(state.text.date, { fontFamily: state.text.font, fontSize: 0.8 * state.ppi * state.text.scale, fill: state.text.color, originX: 'center', originY: 'top', left: x, top: y + mainTextObj.height + (1.0 * state.ppi), selectable: false, evented: false, hoverCursor: 'default' });
                this.canvas.add(dateObj);
            }
            return;
        }
        const group = this._createTextBlockObj(compact, state); group.set({ left: x, top: y, originY: verticalOrigin, hoverCursor: 'default' }); this.canvas.add(group);
    },

    _renderIcon: function(x, y, forcedSize, state) {
        let iconUrl = state.images.icon; let isGhost = false;
        if(!iconUrl) { iconUrl = 'assets/symbols/love_heart_icon.png'; isGhost = true; }
        this._placeImage(iconUrl, x, y, forcedSize || (2.0/1.6)*state.ppi*state.text.scale, { color: state.text.color, opacity: isGhost ? 0.3 : CONFIG.globalOpacity, isIcon: true, hoverCursor: 'pointer' });
    },

    /* V78: NEW STYLE FOR PLACEHOLDER BUTTON (+ Circle with Shadow) */
    _renderImageSlot: function(x, y, state, customSize = null) {
        let w, h;
        if (customSize) { w = customSize.w; h = customSize.h; } 
        else { const zoom = state.text.scale || 1.0; w = state.slotSize.w * state.ppi * zoom; h = state.slotSize.h * state.ppi * zoom; }
        
        let shape;
        const commonOpts = { fill: 'transparent', stroke: '#aaaaaa', strokeWidth: 1.5, strokeDashArray: [10, 10], left: x, top: y, originX: 'center', originY: 'center', selectable: false, evented: true, hoverCursor: 'pointer', isPlaceholder: true };
        if(state.maskType === 'circle') shape = new fabric.Circle({ radius: w/2, ...commonOpts });
        else shape = new fabric.Rect({ width: w, height: h, ...commonOpts });
        this.canvas.add(shape);

        // White Circle Button (matches HTML button style)
        const btnRadius = 25 * (state.ppi / 30); 
        const btnShadow = new fabric.Shadow({ color: 'rgba(0,0,0,0.15)', blur: 10, offsetX: 0, offsetY: 4 });
        
        const btnCircle = new fabric.Circle({ 
            radius: btnRadius, 
            fill: '#ffffff', 
            shadow: btnShadow,
            originX: 'center', 
            originY: 'center', 
            left: x, 
            top: y, 
            selectable: false, 
            evented: false 
        });
        this.canvas.add(btnCircle);

        // Plus Icon
        const plusSize = btnRadius * 0.6; 
        const plusWidth = 2 * (state.ppi / 30); // Thin elegant plus
        
        const vLine = new fabric.Rect({ width: plusWidth, height: plusSize, fill: '#333333', originX: 'center', originY: 'center', left: x, top: y, selectable: false, evented: false });
        const hLine = new fabric.Rect({ width: plusSize, height: plusWidth, fill: '#333333', originX: 'center', originY: 'center', left: x, top: y, selectable: false, evented: false });
        
        this.canvas.add(vLine);
        this.canvas.add(hLine);
    },
    
    _renderNaturalImage: function(x, y, state) {
        if(state.images.main && state.images.main.src) {
            fabric.Image.fromURL(state.images.main.src, (img) => {
                if(!img) return;
                const slotW_px = state.slotSize.w * state.ppi; const slotH_px = state.slotSize.h * state.ppi;
                const scaleX = slotW_px / img.width; const scaleY = slotH_px / img.height;
                const baseScale = Math.min(scaleX, scaleY);
                const userZoom = state.text.scale || 1.0;
                const finalScale = baseScale * userZoom;
                img.set({ left: x, top: y, originX: 'center', originY: 'center', scaleX: finalScale, scaleY: finalScale, opacity: CONFIG.globalOpacity, selectable: false, evented: true, hoverCursor: 'pointer', isMain: true });
                const filter = new fabric.Image.filters.BlendColor({ color: state.text.color, mode: 'tint', alpha: 1 }); 
                img.filters.push(filter); img.applyFilters();
                this.canvas.add(img);
            });
        }
    },

    _placeImage: function(url, x, y, width, opts = {}) {
        fabric.Image.fromURL(url, (img) => {
            if(!img) return;
            img.scaleToWidth(width);
            img.set({ left: x, top: y, originX: 'center', originY: 'center', selectable: false, opacity: CONFIG.globalOpacity, ...opts });
            if(opts.color) { img.filters.push(new fabric.Image.filters.BlendColor({ color: opts.color, mode: 'tint', alpha: 1 })); img.applyFilters(); }
            this.canvas.add(img); if(opts.sendBack) this.canvas.sendToBack(img);
        });
    },

    _placeClippedImage: function(imgData, x, y, w, h, maskType, isBack, state) {
        if(!imgData || !imgData.src) return;
        fabric.Image.fromURL(imgData.src, (img) => {
            const info = imgData.cropInfo; const scaleFactor = w / info.slotPixelSize;
            if(isBack) {
                const coverW = w; const scale = Math.max(coverW / img.width, h / img.height);
                img.set({ scaleX: scale, scaleY: scale, left: x, top: h/2, originX: 'center', originY: 'center', selectable: false, evented: true, hoverCursor: 'pointer', isMain: true });
                img.clipPath = new fabric.Rect({ width: coverW/scale, height: h/scale, left: -coverW/2/scale, top: -h/2/scale });
                this.canvas.add(img); this.canvas.sendToBack(img);
            } else {
                let clip; const absoluteOpts = { left: x, top: y, originX: 'center', originY: 'center', absolutePositioned: true };
                if(maskType === 'circle') { clip = new fabric.Circle({ radius: w/2, ...absoluteOpts }); } 
                else { clip = new fabric.Rect({ width: w, height: h, ...absoluteOpts }); }
                const imgLeft = x + (info.left * scaleFactor); const imgTop = y + (info.top * scaleFactor);
                const totalScale = info.scale * scaleFactor;
                img.set({ left: imgLeft, top: imgTop, scaleX: totalScale, scaleY: totalScale, angle: info.angle || 0, originX: 'center', originY: 'center', selectable: false, evented: true, hoverCursor: 'pointer', isMain: true, clipPath: clip });
                this.canvas.add(img); img.sendToBack(); 
            }
        });
    },
    
    download: function(state) {
        const mult = (CONFIG.dpi / CONFIG.cmToInch) / state.ppi;
        this.canvas.getObjects('line').forEach(o => o.opacity = 0);
        const data = this.canvas.toDataURL({ format: 'png', multiplier: mult, quality: 1 });
        this.canvas.getObjects('line').forEach(o => o.opacity = 0.3);
        const a = document.createElement('a'); a.download = `malevich_cover_${state.bookSize}.png`; a.href = data; a.click();
    }
};

/* --- CROPPER TOOL --- */
const CropperTool = {
    canvas: null, tempImgObject: null, activeSlot: { w: 0, h: 0 }, maskType: 'rect', angle: 0, 
    init: function() {
        if(!this.canvas) {
            const size = Math.min(500, window.innerWidth - 40);
            this.canvas = new fabric.Canvas('cropCanvas', { width: size, height: size, backgroundColor: '#111', selection: false, preserveObjectStacking: true });
            this.canvas.on('object:moving', (e) => { if(e.target === this.tempImgObject) this.constrainImage(e.target); });
        } else {
            const size = Math.min(500, window.innerWidth - 40);
            this.canvas.setDimensions({width: size, height: size});
        }
        this.canvas.clear(); 
        this.canvas.setBackgroundColor('#111', this.canvas.renderAll.bind(this.canvas));
    },
    rotate: function() {
        if(!this.tempImgObject) return;
        this.angle = (this.angle + 90) % 360;
        this.tempImgObject.rotate(this.angle);
        this.recalcMinZoomAndCenter();
        this.canvas.requestRenderAll();
    },
    recalcMinZoomAndCenter: function() {
        if(!this.tempImgObject) return;
        const img = this.tempImgObject;
        const ang = this.angle || 0;
        const isRotated = (Math.abs(ang % 180) === 90);
        const effectiveW = isRotated ? img.height : img.width;
        const effectiveH = isRotated ? img.width : img.height;
        const minScaleX = this.activeSlot.w / effectiveW;
        const minScaleY = this.activeSlot.h / effectiveH;
        const minCoverScale = Math.max(minScaleX, minScaleY);
        img.scale(minCoverScale);
        const cx = this.canvas.width / 2;
        const cy = this.canvas.height / 2;
        img.set({ left: cx, top: cy });
        img.setCoords();
        const slider = document.getElementById('zoomSlider');
        slider.min = minCoverScale;
        slider.max = minCoverScale * 4;
        slider.step = minCoverScale * 0.01;
        slider.value = minCoverScale;
        this.constrainImage(img);
    },
    constrainImage: function(img) {
        const cropW = this.activeSlot.w;
        const cropH = this.activeSlot.h;
        const cx = this.canvas.width / 2;
        const cy = this.canvas.height / 2;
        const ang = img.angle || 0;
        const isRotated = (Math.abs(ang % 180) === 90);
        const imgDisplayW = (isRotated ? img.height : img.width) * img.scaleX;
        const imgDisplayH = (isRotated ? img.width : img.height) * img.scaleY;
        const frameLeft = cx - cropW/2;
        const frameTop = cy - cropH/2;
        const frameRight = cx + cropW/2;
        const frameBottom = cy + cropH/2;
        const maxLeft = frameLeft + imgDisplayW/2;
        const minLeft = frameRight - imgDisplayW/2;
        const maxTop = frameTop + imgDisplayH/2;
        const minTop = frameBottom - imgDisplayH/2;
        if (imgDisplayW >= cropW - 1) img.left = Math.min(Math.max(img.left, minLeft), maxLeft);
        else img.left = cx; 
        if (imgDisplayH >= cropH - 1) img.top = Math.min(Math.max(img.top, minTop), maxTop);
        else img.top = cy;
    },
    start: function(url, slotW, slotH, maskType) {
        this.init();
        this.tempImgObject = null;
        this.maskType = maskType;
        this.angle = 0; 
        this.drawOverlay(slotW, slotH);
        fabric.Image.fromURL(url, (img) => {
            if(!img) return;
            this.tempImgObject = img;
            this.tempImgObject.originX = 'center';
            this.tempImgObject.originY = 'center';
            this.tempImgObject.hasControls = false;
            this.tempImgObject.hasBorders = false;
            this.canvas.add(img);
            this.canvas.setActiveObject(img);
            this.canvas.sendToBack(img);
            this.recalcMinZoomAndCenter();
            const slider = document.getElementById('zoomSlider');
            slider.oninput = () => { img.scale(parseFloat(slider.value)); this.constrainImage(img); this.canvas.requestRenderAll(); };
            this.canvas.requestRenderAll();
        });
    },
    drawOverlay: function(slotW, slotH) {
        this.canvas.getObjects().forEach(o => { if(o !== this.tempImgObject) this.canvas.remove(o); });
        let aspect = slotW / slotH;
        let pW, pH;
        const maxSize = Math.min(400, this.canvas.width * 0.8);
        if(this.maskType === 'circle') { pW = maxSize; pH = maxSize; }
        else if(aspect >= 1) { pW = maxSize; pH = maxSize / aspect; } 
        else { pH = maxSize; pW = maxSize * aspect; }
        this.activeSlot = { w: pW, h: pH };
        const cx = this.canvas.width / 2;
        const cy = this.canvas.height / 2;
        if(this.tempImgObject) { this.canvas.sendToBack(this.tempImgObject); this.recalcMinZoomAndCenter(); }
        let pathStr = `M 0 0 H ${this.canvas.width} V ${this.canvas.height} H 0 Z`; 
        if(this.maskType === 'circle') {
            const r = pW/2;
            pathStr += ` M ${cx} ${cy-r} A ${r} ${r} 0 1 0 ${cx} ${cy+r} A ${r} ${r} 0 1 0 ${cx} ${cy-r} Z`;
            this.canvas.add(new fabric.Circle({ radius: r, left: cx, top: cy, originX:'center', originY:'center', fill: 'transparent', stroke: '#fff', strokeWidth: 1, selectable: false, evented: false }));
        } else {
            pathStr += ` M ${cx-pW/2} ${cy-pH/2} H ${cx+pW/2} V ${cy+pH/2} H ${cx-pW/2} Z`;
            this.canvas.add(new fabric.Rect({ left: cx, top: cy, width: pW, height: pH, fill: 'transparent', stroke: '#fff', strokeWidth: 1, originX: 'center', originY: 'center', selectable: false, evented: false }));
        }
        this.canvas.add(new fabric.Path(pathStr, { fill: 'rgba(0,0,0,0.7)', selectable: false, evented: false, fillRule: 'evenodd' }));
        this.canvas.requestRenderAll();
    },
    apply: function() {
        if(!this.tempImgObject) return null;
        const cx = this.canvas.width / 2;
        const cy = this.canvas.height / 2;
        const offX = this.tempImgObject.left - cx; 
        const offY = this.tempImgObject.top - cy;
        return { src: this.tempImgObject.getSrc(), cropInfo: { left: offX, top: offY, scale: this.tempImgObject.scaleX, slotPixelSize: this.activeSlot.w, angle: this.angle } };
    }
};
